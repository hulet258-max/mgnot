import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { UserProvider } from "./contexts/UserContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { BetSlipProvider } from "./contexts/BetSlipContext";

import MainPage from "./MainPage";
import GamePage from "./GamePage";
import DepositPage from "./DepositPage";
import WithdrawPage from "./withdrawpage";
import PoolSelectionPage from "./PoolSelectionPage";
import GroupPredictionPage from "./GroupPredictionPage";
import DashboardPage from "./DashboardPage";
import DailyMatchPredictionPage from "./DailyMatchPredictionPage";
import LeaderboardPage from "./LeaderboardPage";
import MyPredictionsPage from "./MyPredictionsPage";

function App() {
  return (
    <UserProvider>
      <LanguageProvider>
        <BetSlipProvider>
          <Router>
            <Routes>
              <Route path="/" element={<MainPage />} />
              <Route path="/pools" element={<PoolSelectionPage />} />
              <Route path="/second" element={<PoolSelectionPage />} />
              <Route path="/group-predictions" element={<GroupPredictionPage />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/matches" element={<DailyMatchPredictionPage />} />
              <Route path="/leaderboard" element={<LeaderboardPage />} />
              <Route path="/my-predictions" element={<MyPredictionsPage />} />
              <Route path="/deposit" element={<DepositPage />} />
              <Route path="/withdraw" element={<WithdrawPage />} />
              <Route path="/game/:roomId" element={<GamePage />} />
            </Routes>
          </Router>
        </BetSlipProvider>
      </LanguageProvider>
    </UserProvider>
  );
}

export default App;
