import React, { useMemo, useState } from "react";
import ReactCountryFlag from "react-country-flag";
import { useNavigate } from "react-router-dom";
import TournamentShell from "./TournamentShell";
import { useTournamentState } from "./useTournamentState";
import { useTournamentData } from "./useTournamentData";
import { useLanguage } from "./contexts/LanguageContext";
import { countryCodeByName, getCountryName } from "./countryNames";
import { useGroupPoints } from "./useGroupPoints";
import "./PredictionPages.css";

const getTeamById = (group, teamId) => group.teams.find((team) => team.id === teamId);

function GroupPredictionPage() {
  const navigate = useNavigate();
  const { language, t, formatCurrency } = useLanguage();
  const { groups, pools, loading, error } = useTournamentData();
  const groupPoints = useGroupPoints();
  const {
    groupPredictions,
    groupPredictionsLocked,
    groupCompletion,
    lockedGroupIds,
    savedGroupIds,
    setGroupOrder,
    saveGroupPrediction,
    lockGroupPrediction,
    selectedPoolId,
    joinedPoolIds,
    selectPool,
  } = useTournamentState();
  const [statusMessage, setStatusMessage] = useState("");
  const [dragged, setDragged] = useState(null);

  const getOrderedTeams = (group) => {
    const savedOrder = groupPredictions[group.id] || [];
    const savedTeams = savedOrder.map((teamId) => getTeamById(group, teamId)).filter(Boolean);
    const missingTeams = group.teams.filter((team) => !savedOrder.includes(team.id));
    return [...savedTeams, ...missingTeams].sort((a, b) => {
      if (savedOrder.includes(a.id) || savedOrder.includes(b.id)) return 0;
      return getCountryName(a.name, language).localeCompare(getCountryName(b.name, language));
    });
  };

  const completionText = useMemo(() => `${groupCompletion}%`, [groupCompletion]);
  const arrangementPoints = useMemo(() => {
    return groups.reduce((sum, group) => {
      const orderedTeamIds = (groupPredictions[group.id] || []).slice(0, 2);
      return sum + orderedTeamIds.reduce((teamSum, teamId) => {
        return teamSum + Number(groupPoints[group.id]?.teams?.[teamId]?.points || 3);
      }, 0);
    }, 0);
  }, [groupPoints, groupPredictions, groups]);
  const selectablePools = useMemo(
    () => pools.filter((pool) => joinedPoolIds.includes(pool.id)),
    [joinedPoolIds, pools]
  );

  const moveTeam = (group, fromIndex, toIndex) => {
    if (groupPredictionsLocked || lockedGroupIds.includes(group.id) || fromIndex === toIndex) return;
    const orderedTeams = getOrderedTeams(group);
    const nextTeams = [...orderedTeams];
    const [movedTeam] = nextTeams.splice(fromIndex, 1);
    nextTeams.splice(toIndex, 0, movedTeam);
    setGroupOrder(group.id, nextTeams.map((team) => team.id));
  };

  const handleSaveGroup = async (groupId) => {
    if (!selectedPoolId) return;
    try {
      await saveGroupPrediction(groupId);
      setStatusMessage(t("group.groupSaved", "{{group}} saved", { group: groups.find((group) => group.id === groupId)?.name || "Group" }));
    } catch (error) {
      setStatusMessage(error.message || t("group.saveFailed", "Failed to save group"));
    }
  };

  const handleLockGroup = async (groupId) => {
    if (!selectedPoolId) return;
    try {
      await lockGroupPrediction(groupId);
      setStatusMessage(t("group.groupLocked", "{{group}} locked", { group: groups.find((group) => group.id === groupId)?.name || "Group" }));
    } catch (error) {
      setStatusMessage(error.message || t("group.lockFailed", "Failed to lock group"));
    }
  };

  return (
    <TournamentShell>
      {loading && <div className="wc-empty">{t("common.loading", "Loading...")}</div>}
      {!loading && error && <div className="wc-empty">{error}</div>}
      <section className="group-pool-selector">
        <label>
          <span>{t("group.predictionPool", "Prediction pool")}</span>
          <select value={selectedPoolId || ""} onChange={(event) => selectPool(event.target.value)}>
            <option value="" disabled>{t("group.selectPool", "Select pool")}</option>
            {selectablePools.map((pool) => (
              <option key={pool.id} value={pool.id}>
                {formatCurrency(pool.amount)}
              </option>
            ))}
          </select>
        </label>
        <button className="wc-button secondary" type="button" onClick={() => navigate("/pools")}>
          {t("group.joinAnotherPool", "Join another pool")}
        </button>
      </section>
      {!selectedPoolId && (
        <div className="warning-band">
          {t("group.warning", "Select a pool before locking group predictions.")}
          <button type="button" onClick={() => navigate("/pools")}>
            {t("group.warningChoose", "Choose Pool")}
          </button>
        </div>
      )}

      <section className="group-compact-bar">
        <div>
          <span>{t("group.summary.lockedGroups", "Locked groups")}</span>
          <strong>{completionText}</strong>
        </div>
        <div>
          <span>{t("group.possiblePoints", "Possible points")}</span>
          <strong>{arrangementPoints}</strong>
        </div>
        {statusMessage && <p className="group-save-status">{statusMessage}</p>}
      </section>

      <section className="group-grid wc-section">
        {groups.map((group) => {
          const orderedTeams = getOrderedTeams(group);
          const groupLocked = groupPredictionsLocked || lockedGroupIds.includes(group.id);
          const groupSaved = groupLocked || savedGroupIds.includes(group.id);
          const cardClassName = [
            "group-card",
            groupSaved ? "saved" : "",
            groupLocked ? "locked" : "",
          ].filter(Boolean).join(" ");
          return (
            <article className={cardClassName} key={group.id}>
              <div className="group-card-header">
                <h2>{group.name}</h2>
                <div className="group-card-actions">
                  <span className="wc-pill">
                    {groupLocked ? t("common.locked", "Locked") : groupSaved ? t("common.saved", "Saved") : t("common.open", "Open")}
                  </span>
                  <button
                    className={groupSaved ? "wc-button compact saved" : "wc-button secondary compact"}
                    type="button"
                    disabled={!selectedPoolId || groupLocked}
                    onClick={() => handleSaveGroup(group.id)}
                  >
                    Save
                  </button>
                  <button
                    className="group-lock-button"
                    type="button"
                    aria-label={t("group.lockGroup", "Lock {{group}}", { group: group.name })}
                    title={t("group.lockGroup", "Lock {{group}}", { group: group.name })}
                    disabled={!selectedPoolId || groupLocked}
                    onClick={() => handleLockGroup(group.id)}
                  >
                    <svg viewBox="0 0 24 24" focusable="false" aria-hidden="true">
                      <path d="M17 9h-1V7a4 4 0 0 0-8 0v2H7a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2Zm-7-2a2 2 0 0 1 4 0v2h-4V7Zm7 12H7v-8h10v8Z" />
                    </svg>
                  </button>
                </div>
              </div>

              <ol className="drag-ranking">
                {orderedTeams.map((team, index) => (
                  <li
                    key={team.id}
                    className={`rank-position-${index + 1}`}
                    draggable={!groupLocked}
                    onDragStart={() => setDragged({ groupId: group.id, index })}
                    onDragOver={(event) => event.preventDefault()}
                    onDrop={() => {
                      if (dragged?.groupId === group.id) {
                        moveTeam(group, dragged.index, index);
                      }
                      setDragged(null);
                    }}
                  >
                    <span className="rank-number">{index + 1}</span>
                    <ReactCountryFlag
                      countryCode={countryCodeByName[team.name] || "UN"}
                      svg
                      style={{ width: "2.2em", height: "2.2em" }}
                    />
                    <strong>{getCountryName(team.name, language)}</strong>
                    <span className="team-qualification-points">
                      {t("common.pointsShort", "{{count}} pts", { count: groupPoints[group.id]?.teams?.[team.id]?.points || 3 })}
                    </span>
                    <select
                      value={index + 1}
                      disabled={groupLocked}
                      onChange={(event) => moveTeam(group, index, Number(event.target.value) - 1)}
                      onClick={(event) => event.stopPropagation()}
                    >
                      {orderedTeams.map((_, optionIndex) => (
                        <option key={optionIndex + 1} value={optionIndex + 1}>
                          {optionIndex + 1}
                        </option>
                      ))}
                    </select>
                    <span className="drag-handle">::</span>
                  </li>
                ))}
              </ol>
            </article>
          );
        })}
      </section>

    </TournamentShell>
  );
}

export default GroupPredictionPage;
