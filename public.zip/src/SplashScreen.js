import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './SplashScreen.css';
import logo from './logo.png';

function SplashScreen() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/home'); // Navigate to the main page after 3 seconds
    }, 3000);

    return () => clearTimeout(timer); // Cleanup timer on unmount
  }, [navigate]);

  return (
    <div className="splash-screen">
      {/* Background Elements */}
      <div className="splash-background">
        <div className="bg-pattern"></div>
        <div className="bg-vignette"></div>
        <div className="bg-glow"></div>
      </div>

      {/* Top Spacer */}
      <div className="splash-spacer"></div>

      {/* Main Content */}
      <div className="splash-content">
        <div className="logo-title-container">
          {/* Logo Container */}
          <div className="logo-wrapper">
            <div className="logo-glow animate-pulse-glow"></div>
            <div className="logo-box">
              <img src={logo} alt="አርማ" className="logo-image" />
            </div>
          </div>
          <h1 className="splash-title">KARTA</h1>
        </div>

        {/* Loading State */}
        <div className="loading-state">
          <div className="spinner-container">
            <div className="spinner-ring-bg"></div>
            <div className="spinner-ring animate-spin-slow"></div>
          </div>
          <div className="loading-text-container">
            <h2 className="loading-title">ጨዋታዎ በመጫን ላይ ነው...</h2>
            <p className="loading-subtitle">እባክዎ ይጠብቁ</p>
          </div>
        </div>
      </div>

      {/* Footer Status */}
      <div className="splash-footer">
        <div className="status-pill">
          <span className="material-symbols-outlined status-icon animate-pulse">
            lock
          </span>
          <span className="status-text">ክፍለ ጊዜን በማረጋገጥ ላይ...</span>
        </div>
        <div className="progress-bar-container">
          <div className="progress-bar-fill"></div>
        </div>
      </div>
    </div>
  );
}

export default SplashScreen;