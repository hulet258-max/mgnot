import React, { useEffect, useMemo, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useUser } from "./contexts/UserContext";
import { useLanguage } from "./contexts/LanguageContext";
import { useBetSlip } from "./contexts/BetSlipContext";
import { useTournamentState } from "./useTournamentState";
import { useTournamentData } from "./useTournamentData";
import { getCountryName } from "./countryNames";
import "./TournamentShell.css";

const languageLabels = {
  en: "ENG",
  am: "AMH",
  om: "ORM",
};

function TrophyIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 96 96" aria-hidden="true" focusable="false">
      <path d="M25 14h46v13h14v8c0 15-10 27-25 29-3 4-6 7-9 8v8h16v10H29V80h16v-8c-4-1-7-4-9-8-15-2-25-14-25-29v-8h14V14Zm46 21v18c5-3 8-9 8-17v-1h-8Zm-54 1c0 8 3 14 8 17V35h-8v1Zm18-12v28c0 10 6 17 13 17s13-7 13-17V24H35Z" />
    </svg>
  );
}

function TournamentShell({ children, eyebrow, title, subtitle, actions }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, loading, error } = useUser();
  const { pools } = useTournamentData();
  const { language, setLanguage, t, formatCurrency } = useLanguage();
  const [profileOpen, setProfileOpen] = useState(false);
  const [languageOpen, setLanguageOpen] = useState(false);
  const [profilePools, setProfilePools] = useState([]);
  const [profileLoading, setProfileLoading] = useState(false);
  const displayName = user?.firstName
    ? `${user.firstName} ${user.lastName || ""}`.trim()
    : user?.username || t("profile.defaultName", "Telegram Player");
  const username = user?.username ? `@${user.username}` : t("profile.connectedAccount", "Connected account");
  const initials = useMemo(() => {
    const base = displayName || "Player";
    return base
      .split(" ")
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0])
      .join("")
      .toUpperCase();
  }, [displayName]);
  const API_BASE_URL = process.env.REACT_APP_API_URL;

  const handleLanguageSelect = (nextLanguage) => {
    setLanguage(nextLanguage);
    setLanguageOpen(false);
  };

  useEffect(() => {
    if (!profileOpen || !user?.telegramId) return;
    let cancelled = false;

    const loadProfilePools = async () => {
      setProfileLoading(true);
      try {
        const poolResponse = await fetch(`${API_BASE_URL}/user-pool?userId=${encodeURIComponent(user.telegramId)}`);
        const poolData = await poolResponse.json();
        if (!poolResponse.ok || !poolData.success) return;

        const joinedPoolIds = poolData.joinedPoolIds || [];
        const rows = await Promise.all(joinedPoolIds.map(async (poolId) => {
          const pool = pools.find((item) => item.id === poolId) || { id: poolId, amount: 0 };
          const [leaderboardResponse, predictionsResponse] = await Promise.all([
            fetch(`${API_BASE_URL}/pools/${poolId}/leaderboard`),
            fetch(`${API_BASE_URL}/pools/${poolId}/predictions/${user.telegramId}`),
          ]);
          const leaderboardData = await leaderboardResponse.json();
          const predictionsData = await predictionsResponse.json();
          const leaderboard = leaderboardResponse.ok && leaderboardData.success ? leaderboardData.leaderboard || [] : [];
          const row = leaderboard.find((item) => String(item.userId) === String(user.telegramId));
          const predictionDoc = predictionsResponse.ok && predictionsData.success && predictionsData.exists
            ? predictionsData.predictions || {}
            : {};

          return {
            poolId,
            amount: pool.amount,
            rank: row?.rank || null,
            points: Number(row?.points || 0),
            lockedGroups: Array.isArray(predictionDoc.lockedGroupIds) ? predictionDoc.lockedGroupIds.length : 0,
            possiblePoints: Number(predictionDoc.totalGroupPossiblePoints || 0),
          };
        }));

        if (!cancelled) {
          setProfilePools(rows);
        }
      } catch (profileError) {
        if (!cancelled) {
          setProfilePools([]);
        }
      } finally {
        if (!cancelled) {
          setProfileLoading(false);
        }
      }
    };

    loadProfilePools();

    return () => {
      cancelled = true;
    };
  }, [API_BASE_URL, pools, profileOpen, user?.telegramId]);

  const profileStats = useMemo(() => {
    const totalPoints = profilePools.reduce((sum, pool) => sum + Number(pool.points || 0), 0);
    const rankedPools = profilePools.filter((pool) => pool.rank);
    const bestRank = rankedPools.length ? Math.min(...rankedPools.map((pool) => Number(pool.rank))) : null;
    const lockedGroups = profilePools.reduce((sum, pool) => sum + Number(pool.lockedGroups || 0), 0);
    return { totalPoints, bestRank, lockedGroups };
  }, [profilePools]);

  return (
    <div className="wc-app">
      <div className="wc-page-art" aria-hidden="true">
        <TrophyIcon className="wc-art-trophy wc-art-trophy-main" />
        <TrophyIcon className="wc-art-trophy wc-art-trophy-small" />
        <span className="wc-art-ball" />
        <span className="wc-art-star wc-art-star-one" />
        <span className="wc-art-star wc-art-star-two" />
      </div>
      <header className="wc-topbar">
        <button className="wc-brand" type="button" onClick={() => navigate("/")}> 
          <span className="wc-brand-mark">
            <TrophyIcon className="wc-brand-trophy" />
          </span>
          <span>
            <strong>{t("brand.title", "World Cup")}</strong>
            <small>{t("brand.subtitle", "Predictions")}</small>
          </span>
        </button>

        <div className="wc-topbar-actions">
          <div className="wc-lang-wrap">
            <button
              className="wc-lang-button"
              type="button"
              onClick={() => setLanguageOpen((current) => !current)}
              aria-haspopup="menu"
              aria-expanded={languageOpen}
            >
              {languageLabels[language] || "ENG"}
            </button>
            {languageOpen && (
              <div className="wc-lang-menu" role="menu">
                <button type="button" onClick={() => handleLanguageSelect("en")}>{t("language.english", "English")}</button>
                <button type="button" onClick={() => handleLanguageSelect("am")}>{t("language.amharic", "Amharic")}</button>
                <button type="button" onClick={() => handleLanguageSelect("om")}>{t("language.oromifa", "Oromifa")}</button>
              </div>
            )}
          </div>

          <button
            className="wc-avatar-button"
            type="button"
            onClick={() => setProfileOpen(true)}
            aria-label={t("profile.open", "Open profile")}
          >
            {user?.photo ? (
              <img src={user.photo} alt="" />
            ) : (
              <span>{initials}</span>
            )}
          </button>
        </div>
      </header>
      <nav className="wc-nav" aria-label="Tournament sections">
        <Link className={location.pathname === "/" ? "wc-nav-link active" : "wc-nav-link"} to="/">
          {t("nav.home", "Home page")}
        </Link>
        <Link
          className={location.pathname === "/group-predictions" ? "wc-nav-link active" : "wc-nav-link"}
          to="/group-predictions"
        >
          {t("nav.groupStage", "Group stage")}
        </Link>
        <button className="wc-nav-link wc-nav-link-disabled" type="button" disabled>
          {t("nav.playoffs", "Play offs")}
        </button>
      </nav>

      {profileOpen && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" onClick={() => setProfileOpen(false)}>
          <div className="profile-modal" onClick={(event) => event.stopPropagation()}>
            <div className="profile-header">
              <div className="profile-avatar">
                {user?.photo ? <img src={user.photo} alt="" /> : <span>{initials}</span>}
              </div>
              <div className="profile-title">
                <strong>{loading ? t("common.loading", "Loading...") : displayName}</strong>
                <span>{error ? t("profile.offline", "Telegram sync offline") : username}</span>
              </div>
            </div>

            <div className="profile-stat-grid">
              <div>
                <span>{t("profile.joinedPools", "Joined pools")}</span>
                <strong>{profilePools.length}</strong>
              </div>
              <div>
                <span>{t("profile.totalPoints", "Total points")}</span>
                <strong>{profileStats.totalPoints}</strong>
              </div>
              <div>
                <span>{t("profile.bestRank", "Best rank")}</span>
                <strong>{profileStats.bestRank ? `#${profileStats.bestRank}` : "-"}</strong>
              </div>
              <div>
                <span>{t("profile.lockedGroups", "Locked groups")}</span>
                <strong>{profileStats.lockedGroups}</strong>
              </div>
            </div>

            <div className="profile-pool-summary">
              {profileLoading && <div className="profile-pool-empty">{t("common.loading", "Loading...")}</div>}
              {!profileLoading && profilePools.length === 0 && (
                <div className="profile-pool-empty">{t("profile.noPools", "No joined pools yet.")}</div>
              )}
              {!profileLoading && profilePools.map((pool) => (
                <div className="profile-pool-row" key={pool.poolId}>
                  <div>
                    <span>{t("profile.pool", "Pool")}</span>
                    <strong>{formatCurrency(pool.amount)}</strong>
                  </div>
                  <div>
                    <span>{t("profile.rank", "Rank")}</span>
                    <strong>{pool.rank ? `#${pool.rank}` : "-"}</strong>
                  </div>
                  <div>
                    <span>{t("profile.points", "Points")}</span>
                    <strong>{pool.points}</strong>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <main className="wc-main">
        {(eyebrow || title || subtitle || actions) && (
          <section className="wc-page-heading">
            <div>
              {eyebrow && <p className="wc-eyebrow">{eyebrow}</p>}
              {title && <h1>{title}</h1>}
              {subtitle && <p className="wc-subtitle">{subtitle}</p>}
            </div>
            {actions && <div className="wc-heading-actions">{actions}</div>}
          </section>
        )}
        {children}
      </main>
      <FloatingBetSlip />
    </div>
  );
}

function getOutcomeText(entry, language, t) {
  const { match, prediction } = entry;
  if (prediction.outcome === "home") return getCountryName(match.homeTeam, language);
  if (prediction.outcome === "away") return getCountryName(match.awayTeam, language);
  if (prediction.outcome === "draw") return t("matches.outcome.draw", "Draw");
  return t("common.pending", "Pending");
}

function FloatingBetSlip() {
  const { bets, betCount, expanded, setExpanded, removeBet, clearBets } = useBetSlip();
  const { selectedPoolId, saveMatchPrediction } = useTournamentState();
  const { pools } = useTournamentData();
  const { user } = useUser();
  const { language, t, formatCurrency } = useLanguage();
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [joinedPoolIds, setJoinedPoolIds] = useState([]);
  const [selectedBetPoolIds, setSelectedBetPoolIds] = useState([]);
  const API_BASE_URL = process.env.REACT_APP_API_URL;

  useEffect(() => {
    if (!user?.telegramId) return;
    let cancelled = false;

    const loadJoinedPools = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/user-pool?userId=${encodeURIComponent(user.telegramId)}`);
        const data = await response.json();
        if (!response.ok || !data.success || cancelled) return;

        const nextJoinedPoolIds = data.joinedPoolIds || (data.poolId ? [data.poolId] : []);
        setJoinedPoolIds(nextJoinedPoolIds);
        setSelectedBetPoolIds((current) => {
          const stillJoined = current.filter((poolId) => nextJoinedPoolIds.includes(poolId));
          if (stillJoined.length) return stillJoined;
          const defaultPoolId = data.poolId && nextJoinedPoolIds.includes(data.poolId)
            ? data.poolId
            : nextJoinedPoolIds[0];
          return defaultPoolId ? [defaultPoolId] : [];
        });
      } catch (error) {
        console.warn("Failed to load joined pools for bet slip:", error);
      }
    };

    loadJoinedPools();

    return () => {
      cancelled = true;
    };
  }, [API_BASE_URL, user?.telegramId]);

  useEffect(() => {
    if (!selectedPoolId || !joinedPoolIds.includes(selectedPoolId)) return;
    setSelectedBetPoolIds((current) => (
      current.length ? current : [selectedPoolId]
    ));
  }, [joinedPoolIds, selectedPoolId]);

  if (!betCount && !successMessage) return null;

  const joinedPools = pools.filter((pool) => joinedPoolIds.includes(pool.id));

  const toggleBetPool = (poolId) => {
    setSelectedBetPoolIds((current) => (
      current.includes(poolId)
        ? current.filter((id) => id !== poolId)
        : [...current, poolId]
    ));
    setMessage("");
  };

  const saveAll = async () => {
    if (!selectedBetPoolIds.length) {
      setMessage(t("betSlip.selectPool", "Select at least one joined pool before saving bets."));
      setExpanded(true);
      return;
    }

    setSaving(true);
    setMessage("");
    try {
      const savedPredictions = [];
      for (const poolId of selectedBetPoolIds) {
        for (const entry of bets) {
          await saveMatchPrediction(entry.match.id, entry.prediction, poolId);
          savedPredictions.push({
            poolId,
            matchId: entry.match.id,
            prediction: entry.prediction,
          });
        }
      }
      window.dispatchEvent(new CustomEvent("tournament:match-predictions-saved", {
        detail: { savedPredictions },
      }));
      clearBets();
      setSuccessMessage(t("betSlip.success", "Bets saved successfully."));
      setTimeout(() => setSuccessMessage(""), 2400);
    } catch (error) {
      setMessage(error.message || t("betSlip.failed", "Could not save bets."));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      {successMessage && (
        <div className="bet-slip-success-popup" role="status">
          <strong>{successMessage}</strong>
        </div>
      )}
      {betCount > 0 && (
      <aside className={expanded ? "bet-slip expanded" : "bet-slip"} aria-live="polite">
        <button className="bet-slip-summary" type="button" onClick={() => setExpanded((current) => !current)}>
          <strong>{betCount}</strong>
          <span>{betCount === 1 ? t("betSlip.bet", "Bet") : t("betSlip.bets", "Bets")}</span>
        </button>

        {expanded && (
        <div className="bet-slip-panel">
          <div className="bet-slip-header">
            <div>
              <strong>{t("betSlip.title", "Bet slip")}</strong>
              <span>
                {betCount === 1
                  ? t("betSlip.oneSelection", "1 selection")
                  : t("betSlip.selections", "{{count}} selections", { count: betCount })}
              </span>
            </div>
            <button className="bet-slip-close" type="button" onClick={() => setExpanded(false)} aria-label={t("betSlip.minimize", "Minimize bet slip")}>
              -
            </button>
          </div>
          <div className="bet-slip-pools" aria-label={t("betSlip.saveToPools", "Save to pools")}>
            <span>{t("betSlip.saveToPools", "Save to pools")}</span>
            {joinedPools.length ? (
              <div className="bet-slip-pool-list">
                {joinedPools.map((pool) => (
                  <label key={pool.id} className={selectedBetPoolIds.includes(pool.id) ? "selected" : ""}>
                    <input
                      type="checkbox"
                      checked={selectedBetPoolIds.includes(pool.id)}
                      onChange={() => toggleBetPool(pool.id)}
                    />
                    <strong>{formatCurrency(pool.amount)}</strong>
                    <small>{t(`common.${String(pool.status || "open").toLowerCase()}`, pool.status)}</small>
                  </label>
                ))}
              </div>
            ) : (
              <small>{t("betSlip.joinFirst", "Join a pool first.")}</small>
            )}
          </div>
          <div className="bet-slip-list">
            {bets.map((entry) => (
              <div className="bet-slip-item" key={entry.match.id}>
                <div>
                  <strong>
                    {getCountryName(entry.match.homeTeam, language)} vs {getCountryName(entry.match.awayTeam, language)}
                  </strong>
                  <span>{getOutcomeText(entry, language, t)}</span>
                </div>
                <button className="bet-slip-remove" type="button" onClick={() => removeBet(entry.match.id)}>
                  {t("common.remove", "Remove")}
                </button>
              </div>
            ))}
          </div>
          {message && <div className="bet-slip-message">{message}</div>}
          <div className="bet-slip-actions">
            <button className="wc-button secondary" type="button" onClick={clearBets} disabled={saving}>
              {t("common.cancel", "Cancel")}
            </button>
            <button className="wc-button" type="button" onClick={saveAll} disabled={saving}>
              {saving ? t("betSlip.saving", "Saving...") : t("common.save", "Save")}
            </button>
          </div>
        </div>
        )}
      </aside>
      )}
    </>
  );
}

export default TournamentShell;
