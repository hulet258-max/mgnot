import React, { useEffect, useState } from "react";
import ReactCountryFlag from "react-country-flag";
import { Link, useNavigate } from "react-router-dom";
import TournamentShell from "./TournamentShell";
import { useTournamentState } from "./useTournamentState";
import { useTournamentData } from "./useTournamentData";
import { useUser } from "./contexts/UserContext";
import { useLanguage } from "./contexts/LanguageContext";
import { useBetSlip } from "./contexts/BetSlipContext";
import { getCountryName } from "./countryNames";
import { useMatchOdds } from "./useMatchOdds";
import "./PredictionPages.css";

const formatKickoff = (iso) =>
  new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

const countryByCode = {
  MEX: "MX",
  RSA: "ZA",
  JPN: "JP",
  NZL: "NZ",
  USA: "US",
  COL: "CO",
  GHA: "GH",
  AUS: "AU",
  BRA: "BR",
  DEN: "DK",
  MAR: "MA",
  KOR: "KR",
  FRA: "FR",
  SEN: "SN",
  SCO: "GB",
  CRC: "CR",
  ENG: "GB",
  URU: "UY",
};

const getCountryCode = (code) => countryByCode[code] || "UN";

const playoffRounds = [];

const formatOdd = (value, t) => Number.isFinite(Number(value?.points))
  ? t("common.pointsShort", "{{count}} pts", { count: Number(value.points) })
  : "-";

function MainPage() {
  const navigate = useNavigate();
  const { selectedPoolId, selectPool, matchPredictions, poolPredictions } = useTournamentState();
  const { pools, groups, matchDays, loading, error } = useTournamentData();
  const { user } = useUser();
  const { addBet } = useBetSlip();
  const { language, t, formatCurrency } = useLanguage();
  const oddsByMatch = useMatchOdds();
  const API_BASE_URL = process.env.REACT_APP_API_URL;
  const todayMatches = matchDays[0]?.matches ?? [];
  const [poolLeaderboards, setPoolLeaderboards] = useState({});
  const [activePoolId, setActivePoolId] = useState(null);
  const [joinedPoolIds, setJoinedPoolIds] = useState([]);
  const [paymentPool, setPaymentPool] = useState(null);
  const [paymentMode, setPaymentMode] = useState("text");
  const [receiptMessage, setReceiptMessage] = useState("");
  const [screenshotFile, setScreenshotFile] = useState(null);
  const [screenshotPreviewUrl, setScreenshotPreviewUrl] = useState("");
  const [paymentError, setPaymentError] = useState("");
  const [joiningPoolId, setJoiningPoolId] = useState(null);
  const [homeError, setHomeError] = useState("");
  const [homeMatchPicks, setHomeMatchPicks] = useState({});
  const [joinNoticeMatchId, setJoinNoticeMatchId] = useState(null);

  const getLockedGroupCompletion = (poolId) => {
    const predictionDoc = poolPredictions[poolId] || {};
    if (!groups.length) return 0;
    if (predictionDoc.groupPredictionsLocked) return 100;
    const lockedGroupIds = Array.isArray(predictionDoc.lockedGroupIds)
      ? new Set(predictionDoc.lockedGroupIds)
      : new Set();
    return Math.round((lockedGroupIds.size / groups.length) * 100);
  };

  useEffect(() => {
    setHomeMatchPicks((current) => {
      const savedPicks = Object.entries(matchPredictions || {}).reduce((acc, [matchId, prediction]) => {
        if (prediction?.outcome) acc[matchId] = prediction.outcome;
        return acc;
      }, {});
      return { ...current, ...savedPicks };
    });
  }, [matchPredictions]);

  useEffect(() => {
    if (!pools.length) {
      setPoolLeaderboards({});
      return;
    }

    let cancelled = false;
    const loadLeaders = async () => {
      try {
        const results = await Promise.all(
          pools.map(async (pool) => {
            const response = await fetch(`${API_BASE_URL}/pools/${pool.id}/leaderboard`);
            const data = await response.json();
            return {
              poolId: pool.id,
              leaderboard: response.ok && data.success ? data.leaderboard || [] : [],
            };
          })
        );
        if (!cancelled) {
          setPoolLeaderboards(results.reduce((acc, result) => {
            acc[result.poolId] = result.leaderboard;
            return acc;
          }, {}));
        }
      } catch (err) {
        if (!cancelled) {
          setPoolLeaderboards({});
        }
      }
    };

    loadLeaders();

    return () => {
      cancelled = true;
    };
  }, [API_BASE_URL, pools]);

  useEffect(() => {
    if (!user?.telegramId) return;
    let cancelled = false;

    const loadUserPool = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/user-pool?userId=${encodeURIComponent(user.telegramId)}`);
        const data = await response.json();
        if (!response.ok || !data.success || !data.poolId || cancelled) return;

        const nextJoinedPoolIds = data.joinedPoolIds || (data.poolId ? [data.poolId] : []);
        setJoinedPoolIds(nextJoinedPoolIds);
        if (data.poolId) {
          setActivePoolId(data.poolId);
        }
        if (data.poolId && selectedPoolId !== data.poolId) {
          selectPool(data.poolId);
        }
      } catch (err) {
        console.warn("Failed to check user pool:", err);
      }
    };

    loadUserPool();

    return () => {
      cancelled = true;
    };
  }, [API_BASE_URL, selectPool, selectedPoolId, user?.telegramId]);

  useEffect(() => {
    if (!screenshotFile) {
      setScreenshotPreviewUrl("");
      return undefined;
    }

    const objectUrl = URL.createObjectURL(screenshotFile);
    setScreenshotPreviewUrl(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [screenshotFile]);

  const openPaymentPopup = (pool) => {
    if (!user?.telegramId) {
      setHomeError(t("poolSelection.connectTelegram", "Connect Telegram before joining a pool."));
      return;
    }

    if (joinedPoolIds.includes(pool.id)) {
      setActivePoolId(pool.id);
      selectPool(pool.id);
      navigate("/group-predictions");
      return;
    }

    setPaymentPool(pool);
    setPaymentMode("text");
    setReceiptMessage("");
    setScreenshotFile(null);
    setPaymentError("");
    setHomeError("");
  };

  const extractFromScreenshot = async () => {
    const formData = new FormData();
    formData.append("screenshot", screenshotFile);

    const response = await fetch(`${API_BASE_URL}/ocr-screenshot`, {
      method: "POST",
      body: formData,
    });
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || t("poolSelection.screenshotReadFailed", "Could not read screenshot."));
    }

    return data.transactionId;
  };

  const handleValidatePayment = async () => {
    if (!paymentPool || !user?.telegramId) return;

    if (paymentMode === "text" && !receiptMessage.trim()) {
      setPaymentError(t("poolSelection.pasteReceiptFirst", "Paste the Telebirr message or receipt link first."));
      return;
    }

    if (paymentMode === "screenshot" && !screenshotFile) {
      setPaymentError(t("poolSelection.uploadScreenshotFirst", "Upload a Telebirr screenshot first."));
      return;
    }

    setJoiningPoolId(paymentPool.id);
    setPaymentError("");

    try {
      const receiptTextOrLink = paymentMode === "screenshot"
        ? await extractFromScreenshot()
        : receiptMessage.trim();

      const response = await fetch(`${API_BASE_URL}/pools/${paymentPool.id}/join-payment`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.telegramId,
          receiptTextOrLink,
        }),
      });
      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data?.error || "Failed to validate payment.");
      }

      setActivePoolId(paymentPool.id);
      setJoinedPoolIds((current) => Array.from(new Set([...current, paymentPool.id])));
      selectPool(paymentPool.id);
      setPaymentPool(null);
      navigate("/group-predictions");
    } catch (err) {
      setPaymentError(err.message || t("poolSelection.failedJoin", "Failed to join pool."));
    } finally {
      setJoiningPoolId(null);
    }
  };

  const handleHomeMatchPick = (match, outcome) => {
    if (!joinedPoolIds.length && !selectedPoolId) {
      setJoinNoticeMatchId(match.id);
      setTimeout(() => setJoinNoticeMatchId(null), 2200);
      return;
    }

    if (!isMatchEditable(match)) {
      setHomeError("Match predictions lock 5 minutes before kickoff.");
      return;
    }

    setHomeError("");
    setHomeMatchPicks((current) => ({ ...current, [match.id]: outcome }));
    addBet(match, {
      outcome,
      homeScore: 0,
      awayScore: 0,
      firstToScore: "",
      bothTeamsScore: "",
      totalCorners: "",
      cleanSheet: "",
      bonusEvents: [],
      matchId: match.id,
    });
  };

  return (
    <TournamentShell>
      <section className="home-section">
        <div className="home-section-header">
          <div className="home-section-title">
            <span className="section-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" focusable="false">
                <path d="M12 2.5c4.1 0 7.4 3.1 7.4 7 0 2.5-1.4 4.8-3.7 6.1l-.9 4.1c-.1.4-.5.7-1 .7h-3.6c-.5 0-.9-.3-1-.7l-.9-4.1C6 14.3 4.6 12 4.6 9.5c0-3.9 3.3-7 7.4-7Z" />
              </svg>
            </span>
            <div>
              <h2>{t("home.pools.title", "Choose your pool")} 🏆</h2>
              <p>{t("home.pools.subtitle", "Pick a competition tier and jump into the predictions.")}</p>
            </div>
          </div>
        </div>

        <div className="pool-grid">
          {loading && <div className="wc-empty">{t("common.loading", "Loading...")}</div>}
          {!loading && error && <div className="wc-empty">{error}</div>}
          {homeError && <div className="wc-empty">{homeError}</div>}
          {pools.map((pool) => {
            const joined = joinedPoolIds.includes(pool.id) || (activePoolId || selectedPoolId) === pool.id;
            const lockedGroupCompletion = getLockedGroupCompletion(pool.id);
            const totalPrize = Number(pool.participants || 0) * Number(pool.amount || 0);
            const payouts = [
              { place: t("home.pools.first", "1st"), amount: totalPrize * 0.6, medal: "gold" },
              { place: t("home.pools.second", "2nd"), amount: totalPrize * 0.3, medal: "silver" },
              { place: t("home.pools.third", "3rd"), amount: totalPrize * 0.1, medal: "bronze" },
            ];
            return (
              <button
                key={pool.id}
                className={`pool-tile pool-color-${indexPoolColor(pools, pool.id)}${joined ? " selected joined" : ""}`}
                type="button"
                onClick={() => openPaymentPopup(pool)}
              >
                <div className="pool-tile-top">
                  <span className={joined ? "wc-pill joined-pill" : "wc-pill"}>
                    {joined
                      ? t("home.pools.joinedProgress", "Joined {{count}}%", { count: lockedGroupCompletion })
                      : t("common.open", "Open")}
                  </span>
                  <span className="pool-amount">{formatCurrency(pool.amount)}</span>
                </div>
                <div className="pool-tile-body">
                  <span>{t("home.pools.totalPrize", "Total prize pool")}</span>
                  <strong>{formatCurrency(totalPrize)}</strong>
                </div>
                <div className="pool-payouts">
                  {payouts.map((payout) => (
                    <div key={payout.place}>
                      <span className={`pool-trophy ${payout.medal}`} aria-hidden="true">
                        <svg viewBox="0 0 24 24" focusable="false">
                          <path d="M7 3h10v3h3v2.2c0 3.7-2.3 6.4-5.7 7.1-.5.6-1.1 1-1.8 1.2V19H16v2H8v-2h3.5v-2.5c-.7-.2-1.3-.6-1.8-1.2C6.3 14.6 4 11.9 4 8.2V6h3V3Zm10 5v4.7c1.2-.7 2-2.2 2-4.4V8h-2ZM6 8v.3c0 2.2.8 3.7 2 4.4V8H6Zm4-3v7.6c0 1.5.9 2.6 2 2.6s2-1.1 2-2.6V5h-4Z" />
                        </svg>
                      </span>
                      <span>{payout.place}</span>
                      <strong>{formatCurrency(Math.round(payout.amount))}</strong>
                    </div>
                  ))}
                </div>
                <div className="pool-tile-meta">
                  <div>
                    <span>{t("home.pools.players", "Players")}</span>
                    <strong>{pool.participants}</strong>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <section className="home-section">
        <div className="home-section-header">
          <div className="home-section-title">
            <span className="section-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" focusable="false">
                <path d="M12 2.7c-5.1 0-9.3 4.2-9.3 9.3s4.2 9.3 9.3 9.3 9.3-4.2 9.3-9.3S17.1 2.7 12 2.7Zm0 2.2a7.1 7.1 0 0 1 7.1 7.1 7.1 7.1 0 0 1-7.1 7.1 7.1 7.1 0 0 1-7.1-7.1A7.1 7.1 0 0 1 12 4.9Zm-1.1 2.5v4.2l-3 1.8 1.1 1.8 4.1-2.4V7.4h-2.2Z" />
              </svg>
            </span>
            <div>
              <h2>{t("home.matches.title", "Today matches")} ⚽</h2>
              <p>{t("home.matches.subtitle", "Tap a team to place your bets.")}</p>
            </div>
          </div>
          <button className="wc-button" type="button" onClick={() => navigate("/matches")}>
            {t("home.matches.betMore", "Bet more")}
          </button>
        </div>

        <div className="match-grid">
          {!loading && todayMatches.length === 0 && (
            <div className="wc-empty">{t("matches.empty", "No matches available yet.")}</div>
          )}
          {todayMatches.map((match) => (
            <div
              key={match.id}
              className="match-tile"
              role="button"
              tabIndex={0}
              onClick={() => navigate("/matches")}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  navigate("/matches");
                }
              }}
            >
              {joinNoticeMatchId === match.id && (
                <div className="join-pool-popover">{t("betSlip.joinFirst", "Join a pool first.")}</div>
              )}
              <div className="match-tile-top">
                <span>{match.group}</span>
                <span>{formatKickoff(match.kickoff)}</span>
              </div>
              <div className="match-teams">
                <button
                  className={homeMatchPicks[match.id] === "home" ? "team-line selected" : "team-line"}
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    handleHomeMatchPick(match, "home");
                  }}
                >
                  <PoolOutcomeMarkers
                    pools={pools}
                    poolPredictions={poolPredictions}
                    matchId={match.id}
                    outcome="home"
                    t={t}
                    formatCurrency={formatCurrency}
                  />
                  <span className="team-flag" aria-hidden="true">
                    <ReactCountryFlag
                      countryCode={getCountryCode(match.homeCode)}
                      svg
                      style={{ width: "2.2em", height: "2.2em" }}
                    />
                  </span>
                  <span className="team-pick-copy">
                    <strong>{getCountryName(match.homeTeam, language)}</strong>
                    <small>{formatOdd(oddsByMatch[match.id]?.home, t)}</small>
                  </span>
                </button>
                <div className="home-match-choice">
                  <button
                    className={homeMatchPicks[match.id] === "draw" ? "team-line draw selected" : "team-line draw"}
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      handleHomeMatchPick(match, "draw");
                    }}
                  >
                    <PoolOutcomeMarkers
                      pools={pools}
                      poolPredictions={poolPredictions}
                      matchId={match.id}
                      outcome="draw"
                      t={t}
                      formatCurrency={formatCurrency}
                    />
                    <span className="team-pick-copy centered">
                      <strong>{t("matches.outcome.draw", "Draw")}</strong>
                      <small>{formatOdd(oddsByMatch[match.id]?.draw, t)}</small>
                    </span>
                  </button>
                </div>
                <button
                  className={homeMatchPicks[match.id] === "away" ? "team-line selected" : "team-line"}
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    handleHomeMatchPick(match, "away");
                  }}
                >
                  <PoolOutcomeMarkers
                    pools={pools}
                    poolPredictions={poolPredictions}
                    matchId={match.id}
                    outcome="away"
                    t={t}
                    formatCurrency={formatCurrency}
                  />
                  <span className="team-flag" aria-hidden="true">
                    <ReactCountryFlag
                      countryCode={getCountryCode(match.awayCode)}
                      svg
                      style={{ width: "2.2em", height: "2.2em" }}
                    />
                  </span>
                  <span className="team-pick-copy">
                    <strong>{getCountryName(match.awayTeam, language)}</strong>
                    <small>{formatOdd(oddsByMatch[match.id]?.away, t)}</small>
                  </span>
                </button>
              </div>
              <div className="match-cta">
                <span>{t("home.matches.betNow", "Bet now")}</span>
                <svg viewBox="0 0 24 24" focusable="false">
                  <path d="M5 12h12.2l-4.4-4.4 1.6-1.6 7.1 7.1-7.1 7.1-1.6-1.6 4.4-4.4H5z" />
                </svg>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="home-section">
        <div className="home-section-header">
          <div className="home-section-title">
            <span className="section-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" focusable="false">
                <path d="M7 3h10l1 6c0 2.1-1.3 4.1-3.3 5-1.4.7-2.2 1.7-2.2 3v1h2.7v2.3H8.8V18h2.7v-1c0-1.3-.8-2.3-2.2-3-2-1-3.3-2.9-3.3-5l1-6Zm2.1 2.2-.6 3.6c0 1.2.7 2.3 1.9 2.8 1.4.7 2.4 1.6 2.9 2.7.6-1.1 1.6-2 2.9-2.7 1.2-.5 1.9-1.6 1.9-2.8l-.6-3.6H9.1Z" />
              </svg>
            </span>
            <div>
              <h2>{t("home.leaderboards.title", "Leaderboards")} 🏆</h2>
              <p>{t("home.leaderboards.subtitle", "See who is leading the pools right now.")}</p>
            </div>
          </div>
          <Link className="wc-button secondary" to="/leaderboard">
            {t("home.leaderboards.viewAll", "View all")}
          </Link>
        </div>

        <div className="home-leaderboard-grid">
          {pools.map((pool) => {
            const leaderboard = poolLeaderboards[pool.id] || [];
            const currentUserId = String(user?.telegramId || user?.id || "");
            const currentUserRow = leaderboard.find((row) => String(row.userId) === currentUserId);
            const rows = leaderboard.slice(0, 5);
            const displayRows = currentUserRow && !rows.some((row) => String(row.userId) === currentUserId)
              ? [...rows, currentUserRow]
              : rows;

            return (
              <div className={`leaderboard-pool-card pool-color-${indexPoolColor(pools, pool.id)}`} key={pool.id}>
                <div className="leaderboard-pool-title">
                  <strong>{t("currency.pool", "{{amount}} Birr pool", { amount: Number(pool.amount || 0).toLocaleString() })}</strong>
                  {currentUserRow && <span>Your position #{currentUserRow.rank}</span>}
                </div>
                <div className="leader-list">
                  {displayRows.length === 0 && (
                    <div className="wc-empty">{t("leaderboard.empty", "Join a pool to start the leaderboard.")}</div>
                  )}
                  {displayRows.map((row) => {
                    const isCurrentUser = String(row.userId) === currentUserId;
                    return (
                      <div className={isCurrentUser ? "leader-row current-user" : "leader-row"} key={row.userId}>
                        <div className="leader-rank">#{row.rank}</div>
                        <div className="leader-meta">
                          <strong>{row.username}</strong>
                          <span>{t("common.pointsShort", "{{count}} pts", { count: row.points })}</span>
                        </div>
                        <div className="leader-chip">{String(row.username || "P").slice(0, 2).toUpperCase()}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {false && <section className="home-section playoffs-section">
        <div className="home-section-header">
          <div className="home-section-title">
            <span className="section-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" focusable="false">
                <path d="M5 4h14v4h3v2c0 4.6-2.8 7.9-7 8.6V21H9v-2.4c-4.2-.7-7-4-7-8.6V8h3V4Zm14 6v5.5c1.4-.8 2.2-2.6 2.2-5V10H19ZM2.8 10v.5c0 2.4.8 4.2 2.2 5V10H2.8ZM7 6v9.8c0 2.1 1.9 3.8 5 3.8s5-1.7 5-3.8V6H7Z" />
              </svg>
            </span>
            <div>
              <h2>Playoffs</h2>
              <p>Inactive for now. The bracket will open after the group stage.</p>
            </div>
          </div>
          <span className="wc-pill playoffs-pill">Inactive</span>
        </div>

        <div className="playoff-bracket" aria-label="Playoff match structure">
          {playoffRounds.map((round) => (
            <div className="playoff-round" key={round.title}>
              <span>{round.title}</span>
              <div className="playoff-match-stack">
                {Array.from({ length: round.matches }).map((_, index) => (
                  <div className="playoff-match-node" key={`${round.title}-${index}`}>
                    Match {index + 1}
                  </div>
                ))}
              </div>
            </div>
          ))}
          <div className="playoff-trophy" aria-hidden="true">
            <svg viewBox="0 0 96 96" focusable="false">
              <path d="M25 14h46v13h14v8c0 15-10 27-25 29-3 4-6 7-9 8v8h16v10H29V80h16v-8c-4-1-7-4-9-8-15-2-25-14-25-29v-8h14V14Zm46 21v18c5-3 8-9 8-17v-1h-8Zm-54 1c0 8 3 14 8 17V35h-8v1Zm18-12v28c0 10 6 17 13 17s13-7 13-17V24H35Z" />
            </svg>
          </div>
        </div>
      </section>}

      {paymentPool && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="home-pool-payment-title">
          <div className="confirm-modal pool-payment-modal">
            <h2 id="home-pool-payment-title">
              {t("poolSelection.payTitle", "Pay {{amount}} Birr in Telebirr", { amount: Number(paymentPool.amount || 0).toLocaleString() })}
            </h2>
            <p>
              {t("poolSelection.payBody", "Send exactly {{amount}} Birr for the {{amount}} Birr pool, then paste the Telebirr message/link or upload a screenshot.", {
                amount: Number(paymentPool.amount || 0).toLocaleString(),
              })}
            </p>

            <div className="pool-payment-modes">
              <button
                className={paymentMode === "text" ? "wc-button" : "wc-button secondary"}
                type="button"
                onClick={() => setPaymentMode("text")}
              >
                {t("poolSelection.message", "Message")}
              </button>
              <button
                className={paymentMode === "screenshot" ? "wc-button" : "wc-button secondary"}
                type="button"
                onClick={() => setPaymentMode("screenshot")}
              >
                {t("poolSelection.screenshot", "Screenshot")}
              </button>
            </div>

            {paymentMode === "text" ? (
              <textarea
                className="pool-payment-textarea"
                value={receiptMessage}
                onChange={(event) => setReceiptMessage(event.target.value)}
                placeholder={t("poolSelection.receiptPlaceholder", "Paste the Telebirr sent message or receipt link...")}
              />
            ) : (
              <div className="pool-payment-upload">
                <input
                  id="homePoolPaymentScreenshot"
                  type="file"
                  accept="image/*"
                  onChange={(event) => setScreenshotFile(event.target.files?.[0] || null)}
                />
                {screenshotFile && <strong>{screenshotFile.name}</strong>}
                {screenshotPreviewUrl && <img src={screenshotPreviewUrl} alt={t("poolSelection.screenshotPreviewAlt", "Telebirr payment screenshot preview")} />}
              </div>
            )}

            {paymentError && <div className="wc-empty">{paymentError}</div>}

            <div className="modal-actions">
              <button className="wc-button secondary" type="button" onClick={() => setPaymentPool(null)}>
                {t("common.cancel", "Cancel")}
              </button>
              <button
                className="wc-button"
                type="button"
                disabled={joiningPoolId === paymentPool.id}
                onClick={handleValidatePayment}
              >
                {joiningPoolId === paymentPool.id
                  ? t("common.validating", "Validating...")
                  : t("poolSelection.validatePayment", "Validate Payment")}
              </button>
            </div>
          </div>
        </div>
      )}
    </TournamentShell>
  );
}

function isMatchEditable(match) {
  return match.status === "open" && Date.now() < new Date(match.kickoff).getTime() - (5 * 60 * 1000);
}

function indexPoolColor(pools, poolId) {
  return Math.max(0, pools.findIndex((pool) => pool.id === poolId)) % 3;
}

function PoolOutcomeMarkers({ pools, poolPredictions, matchId, outcome, t, formatCurrency }) {
  const matchingPools = pools.filter((pool) => (
    poolPredictions?.[pool.id]?.matchPredictions?.[matchId]?.outcome === outcome
  ));

  if (!matchingPools.length) return null;

  return (
    <span className="prediction-pool-markers" aria-label={t("betSlip.saveToPools", "Save to pools")}>
      {matchingPools.map((pool) => (
        <span
          key={pool.id}
          className={`prediction-pool-marker pool-marker-${indexPoolColor(pools, pool.id)}`}
          title={t("currency.pool", "{{amount}} Birr pool", { amount: Number(pool.amount || 0).toLocaleString() })}
        >
          {formatCurrency(pool.amount)}
        </span>
      ))}
    </span>
  );
}

export default MainPage;
