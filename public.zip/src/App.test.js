import { render, screen } from "@testing-library/react";
import App from "./App";

jest.mock(
  "react-router-dom",
  () => {
    const React = require("react");
    const anchor = ({ children, to, className }) =>
      React.createElement("a", { href: to, className }, children);

    return {
      BrowserRouter: ({ children }) => React.createElement(React.Fragment, null, children),
      Routes: ({ children }) => {
        const firstRoute = React.Children.toArray(children)[0];
        return firstRoute?.props?.element || null;
      },
      Route: () => null,
      Link: anchor,
      NavLink: ({ children, to, className }) =>
        React.createElement(
          "a",
          {
            href: to,
            className: typeof className === "function" ? className({ isActive: false }) : className,
          },
          children
        ),
      useNavigate: () => jest.fn(),
    };
  },
  { virtual: true }
);

test("renders the tournament prediction home page", async () => {
  render(<App />);

  expect(await screen.findByText(/World Cup Prediction Challenge/i)).toBeInTheDocument();
  expect(screen.getByRole("button", { name: /Join a Pool/i })).toBeInTheDocument();
});
