import React, { useEffect, useMemo, useState } from "react";
import TournamentShell from "./TournamentShell";
import { useTournamentState } from "./useTournamentState";
import { useUser } from "./contexts/UserContext";
import { useTournamentData } from "./useTournamentData";
import { useLanguage } from "./contexts/LanguageContext";
import { socket } from "./socket";
import "./PredictionPages.css";

function LeaderboardPage() {
  const { user } = useUser();
  const { t, formatCurrency } = useLanguage();
  const { pools, loading: tournamentLoading, error: tournamentError } = useTournamentData();
  const { selectedPoolId, matchPredictions, groupPredictionsLocked } = useTournamentState();
  const [poolFilter, setPoolFilter] = useState(selectedPoolId || "all");
  const [rankFilter, setRankFilter] = useState("overall");
  const [timeFilter, setTimeFilter] = useState("group");
  const [remoteRows, setRemoteRows] = useState([]);
  const [leaderboardError, setLeaderboardError] = useState("");
  const API_BASE_URL = process.env.REACT_APP_API_URL;
  const savedMatches = Object.keys(matchPredictions).length;

  useEffect(() => {
    const poolId = poolFilter !== "all" ? poolFilter : selectedPoolId;
    if (!poolId) {
      setRemoteRows([]);
      return;
    }

    let cancelled = false;
    const loadLeaderboard = async () => {
      setLeaderboardError("");
      try {
        const response = await fetch(`${API_BASE_URL}/pools/${poolId}/leaderboard`);
        const data = await response.json();

        if (!response.ok || !data.success) {
          throw new Error(data?.error || "Failed to load leaderboard.");
        }

        if (!cancelled) {
          setRemoteRows(data.leaderboard || []);
        }
      } catch (err) {
        if (!cancelled) {
          setRemoteRows([]);
          setLeaderboardError(err.message || "Failed to load leaderboard.");
        }
      }
    };

    loadLeaderboard();
    socket.on("pool_updated", loadLeaderboard);
    window.addEventListener("tournament:pool-updated", loadLeaderboard);

    return () => {
      cancelled = true;
      socket.off("pool_updated", loadLeaderboard);
      window.removeEventListener("tournament:pool-updated", loadLeaderboard);
    };
  }, [API_BASE_URL, poolFilter, selectedPoolId]);

  const rows = useMemo(() => {
    const userRow = {
      id: "current-user",
      username: user?.username || user?.firstName || t("leaderboard.you", "You"),
      avatar: (user?.firstName || "Y").slice(0, 2).toUpperCase(),
      points: (groupPredictionsLocked ? 24 : 0) + savedMatches * 3 + 12,
      accuracy: savedMatches ? Math.min(90, 60 + savedMatches * 5) : 0,
      streak: Math.min(savedMatches, 8),
      movement: savedMatches ? "up" : "stable",
      isCurrentUser: true,
    };

    return [...remoteRows, userRow]
      .sort((a, b) => b.points - a.points)
      .map((row, index) => ({
        ...row,
        rank: index + 1,
      }));
  }, [groupPredictionsLocked, remoteRows, savedMatches, t, user]);

  const currentUserRow = rows.find((row) => row.isCurrentUser);
  const closestCompetitors = rows
    .filter((row) => !row.isCurrentUser)
    .slice(Math.max((currentUserRow?.rank || 3) - 3, 0), Math.max((currentUserRow?.rank || 3) + 1, 3));

  return (
    <TournamentShell
      eyebrow={t("leaderboard.eyebrow", "Leaderboard")}
      title={t("leaderboard.title", "Pool Rankings")}
      subtitle={t(
        "leaderboard.subtitle",
        "Filter rankings, track movement, and see how close you are to the qualification zone."
      )}
    >
      {tournamentLoading && <div className="wc-empty">{t("common.loading", "Loading...")}</div>}
      {!tournamentLoading && (tournamentError || leaderboardError) && (
        <div className="wc-empty">{tournamentError || leaderboardError}</div>
      )}
      <section className="filter-bar">
        <label>
          <span>{t("leaderboard.filter.pool", "Pool")}</span>
          <select value={poolFilter} onChange={(event) => setPoolFilter(event.target.value)}>
            <option value="all">{t("leaderboard.filter.allPools", "All pools")}</option>
            {pools.map((pool) => (
              <option key={pool.id} value={pool.id}>
                {formatCurrency(pool.amount)}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span>{t("leaderboard.filter.ranking", "Ranking")}</span>
          <select value={rankFilter} onChange={(event) => setRankFilter(event.target.value)}>
            <option value="overall">{t("leaderboard.filter.overall", "Overall")}</option>
            <option value="my-pool">{t("leaderboard.filter.myPool", "My pool")}</option>
            <option value="qualification">{t("leaderboard.filter.qualification", "Qualification zone")}</option>
          </select>
        </label>
        <label>
          <span>{t("leaderboard.filter.time", "Time")}</span>
          <select value={timeFilter} onChange={(event) => setTimeFilter(event.target.value)}>
            <option value="group">{t("leaderboard.filter.groupStage", "Group stage")}</option>
            <option value="today">{t("leaderboard.filter.today", "Today")}</option>
            <option value="all">{t("leaderboard.filter.allTime", "All time")}</option>
          </select>
        </label>
      </section>

      <section className="leaderboard-table-wrap">
        <table className="leaderboard-table">
          <thead>
            <tr>
              <th>{t("leaderboard.table.rank", "Rank")}</th>
              <th>{t("leaderboard.table.user", "User")}</th>
              <th>{t("leaderboard.table.points", "Points")}</th>
              <th>{t("leaderboard.table.accuracy", "Accuracy")}</th>
              <th>{t("leaderboard.table.streak", "Streak")}</th>
              <th>{t("leaderboard.table.move", "Move")}</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id} className={row.isCurrentUser ? "current-user-row" : ""}>
                <td>#{row.rank}</td>
                <td>
                  <div className="leader-user">
                    <span>{row.avatar || String(row.username || "P").slice(0, 2).toUpperCase()}</span>
                    <strong>
                      {row.isCurrentUser ? `${row.username} (${t("leaderboard.you", "You")})` : row.username}
                    </strong>
                  </div>
                </td>
                <td>{row.points}</td>
                <td>{row.accuracy}%</td>
                <td>{row.streak}</td>
                <td>
                  <span
                    className={`movement movement-${row.movement}`}
                    aria-label={t(`leaderboard.movement.${row.movement}`, "Movement")}
                  >
                    <span className="movement-arrow" />
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="wc-section leaderboard-panels">
        <div>
          <h2 className="wc-section-title">{t("leaderboard.panels.top", "Top Performers")}</h2>
          <div className="mini-rank-list">
            {rows.slice(0, 3).map((row) => (
              <div key={row.id}>
                <span>#{row.rank}</span>
                <strong>{row.username}</strong>
                <b>{t("common.pointsShort", "{{count}} pts", { count: row.points })}</b>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="wc-section-title">{t("leaderboard.panels.closest", "Closest Competitors")}</h2>
          <div className="mini-rank-list">
            {closestCompetitors.map((row) => (
              <div key={row.id}>
                <span>#{row.rank}</span>
                <strong>{row.username}</strong>
                <b>{t("common.pointsShort", "{{count}} pts", { count: row.points })}</b>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="wc-section-title">{t("leaderboard.panels.zone", "Qualification Zone")}</h2>
          <div className="qualification-zone">
            <strong>{t("leaderboard.panels.topPercent", "Top 40%")}</strong>
            <span>
              {currentUserRow
                ? t("leaderboard.panels.currentRank", "You are currently #{{rank}}.", { rank: currentUserRow.rank })
                : t("leaderboard.panels.joinPool", "Join a pool to appear here.")}
            </span>
          </div>
        </div>
      </section>
    </TournamentShell>
  );
}

export default LeaderboardPage;
